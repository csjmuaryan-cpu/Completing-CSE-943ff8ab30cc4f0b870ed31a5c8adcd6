interface WithdrawalLimitUpdatable {
  updateWithdrawalLimit(amount: number): void;
}
