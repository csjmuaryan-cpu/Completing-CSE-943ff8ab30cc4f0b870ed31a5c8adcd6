import React from "react";

export function App() {
    return <h1>Hello, I am coming from App.js now.</h1>
    // return React.createElement("h1", { id: "heading", className: "heading" }, "Hello, I am coming from App.js file via React element.");
}