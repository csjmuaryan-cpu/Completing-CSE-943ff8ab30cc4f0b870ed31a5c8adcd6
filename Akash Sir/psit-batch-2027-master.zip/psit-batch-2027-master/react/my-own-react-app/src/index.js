import ReactDOM from 'react-dom/client';
import { App } from './App';

const root = ReactDOM.createRoot(document.getElementById('aakash'));
// root.innerHTML = "Hello I am coming from div.";

root.render(
    <App />
);