import React from "react";


export function App() {
  return <h1 id="heading" className="heading">Hello, I am coming from App.js file.</h1>;

  // return React.createElement("h1", { id: "heading", className: "heading" }, "Hello, I am coming from App.js file via React element.");
}