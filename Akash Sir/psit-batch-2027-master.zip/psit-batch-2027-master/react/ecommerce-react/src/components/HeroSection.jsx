function HeroSection() {
  return (
    <section class='hero'>
      <div>
        <img
          class='hero-banner'
          src='https://i.postimg.cc/pXHbTWPP/banner1.avif'
          alt='Sale'
        />
      </div>
    </section>
  );
}

export default HeroSection;
