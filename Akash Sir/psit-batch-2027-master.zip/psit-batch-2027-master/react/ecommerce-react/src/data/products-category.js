const productCategories = [
  {
    id: 1,
    name: 'Men',
    image: 'https://i.postimg.cc/pXx4vsBT/menstyle.avif',
  },
  {
    id: 2,
    name: 'Woman',
    image: 'https://i.postimg.cc/BbJgrVGf/womenstyle.avif',
  },
  {
    id: 3,
    name: 'Kids',
    image: 'https://i.postimg.cc/BbJgrVGf/womenstyle.avif',
  },
  {
    id: 4,
    name: 'Home and Living',
    image: 'https://i.postimg.cc/DzmRDmPP/homeandliving.avif',
  },
  {
    id: 5,
    name: 'Beauty',
    image: 'https://i.postimg.cc/J45wHfhZ/beauty.avif',
  },
];

export default productCategories;
