const products = [
  {
    id: 1,
    name: 'Sports Yellow Suit',
    image: 'https://i.postimg.cc/2SStb3MN/product1.avif',
    rating: 3.8,
    price: 199900,
  },
  {
    id: 2,
    name: 'Beige Blazer',
    image: 'https://i.postimg.cc/jq63Mzrr/product2.avif',
    rating: 4.2,
    price: 299900,
  },
  {
    id: 3,
    name: 'Red T-Shirt',
    image: 'https://i.postimg.cc/Y07npSYV/product3.avif',
    rating: 4.1,
    price: 189900,
  },
  {
    id: 4,
    name: 'Black Top',
    image: 'https://i.postimg.cc/tTWvQ6ZW/product4.avif',
    rating: 4.5,
    price: 179900,
  },
  {
    id: 5,
    name: 'Space Black Shirt',
    image: 'https://i.postimg.cc/C54vdV4K/product5.avif',
    rating: 4.9,
    price: 299900,
  },
  {
    id: 6,
    name: 'Black Lower',
    image: 'https://i.postimg.cc/gkYSQnYL/product6.avif',
    rating: 4.2,
    price: 139900,
  },
  {
    id: 7,
    name: 'Green Suit',
    image: 'https://i.postimg.cc/kgHT2sWW/product7.avif',
    rating: 3.5,
    price: 199900,
  },
  {
    id: 8,
    name: 'Denim Blue Jacket',
    image: 'https://i.postimg.cc/qvqmBS6k/product8.avif',
    rating: 3.9,
    price: 399900,
  },
  {
    id: 9,
    name: 'Brown Jacket',
    image: 'https://i.postimg.cc/1thMHzCt/product9.avif',
    rating: 3.8,
    price: 699900,
  },
  {
    id: 10,
    name: 'Off White Long Blazer',
    image: 'https://i.postimg.cc/k4Qshdzy/product10.avif',
    rating: 4.9,
    price: 499900,
  },
];

export default products;
